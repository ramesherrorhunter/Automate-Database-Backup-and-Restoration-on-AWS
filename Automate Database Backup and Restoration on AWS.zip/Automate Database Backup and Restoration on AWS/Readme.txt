prerequisite to run project -

python
docker
mysql.exe
mysqldump.exe

how to run project -

create S3 bucket,
create MYSQL RDS instance,
create ECS and push docker file in created repository,
create lambda function and select from image,
test the lambda function,





